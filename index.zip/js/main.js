//demo 01
$("#about").animatedModal({
    color:'#000'
});
$("#resume").animatedModal({
    color:'#000'
});

$("#portfolio").animatedModal({
    color:'#000'
});

$("#contact").animatedModal({
    color:'#000'
});