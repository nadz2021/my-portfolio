<?php
//reCAPTCHA Configuration - go to Google and get the below keys http://www.google.com/recaptcha/admin
define('SITE_KEY',"6Le-QPYUAAAAAOVHzyHFL7YjiYze8Ey2UJolA3Yy"); 
define('SECRET_KEY',"6Le-QPYUAAAAAALUQMTKFYnbY09hG5qv8Zn5YpIa");
?>